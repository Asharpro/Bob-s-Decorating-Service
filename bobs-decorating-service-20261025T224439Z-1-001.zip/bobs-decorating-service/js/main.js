/**
 * Bob's Decorating Service, Corp. - Main Website Script
 * Interactive UI, Before/After Slider, Accordion, Quote Form, ZIP Checker
 */

(function () {
  'use strict';

  // 1. Sticky Header & Back to Top
  const header = document.querySelector('.main-header');
  const backToTopBtn = document.getElementById('back-to-top');

  window.addEventListener('scroll', () => {
    const scrollY = window.scrollY;

    if (header) {
      if (scrollY > 40) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    }

    if (backToTopBtn) {
      if (scrollY > 600) {
        backToTopBtn.classList.add('visible');
      } else {
        backToTopBtn.classList.remove('visible');
      }
    }

    // Scroll spy for active nav link
    updateActiveNav();
  });

  if (backToTopBtn) {
    backToTopBtn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // 2. Mobile Navigation Drawer
  const mobileToggle = document.getElementById('mobile-nav-toggle');
  const mobileDrawer = document.getElementById('mobile-nav-drawer');
  const mobileBackdrop = document.getElementById('mobile-nav-backdrop');
  const drawerCloseBtn = document.getElementById('drawer-close-btn');
  const mobileNavLinks = document.querySelectorAll('.mobile-nav-item a');

  function openMobileNav() {
    if (mobileDrawer) mobileDrawer.classList.add('open');
    if (mobileBackdrop) mobileBackdrop.classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  function closeMobileNav() {
    if (mobileDrawer) mobileDrawer.classList.remove('open');
    if (mobileBackdrop) mobileBackdrop.classList.remove('open');
    document.body.style.overflow = '';
  }

  if (mobileToggle) mobileToggle.addEventListener('click', openMobileNav);
  if (drawerCloseBtn) drawerCloseBtn.addEventListener('click', closeMobileNav);
  if (mobileBackdrop) mobileBackdrop.addEventListener('click', closeMobileNav);

  mobileNavLinks.forEach(link => {
    link.addEventListener('click', closeMobileNav);
  });

  // 3. Scroll Spy for Desktop Navigation
  const sections = document.querySelectorAll('section[id]');
  const desktopNavLinks = document.querySelectorAll('.nav-desktop .nav-link');

  function updateActiveNav() {
    const scrollY = window.pageYOffset;

    sections.forEach(current => {
      const sectionHeight = current.offsetHeight;
      const sectionTop = current.offsetTop - 120;
      const sectionId = current.getAttribute('id');

      if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
        desktopNavLinks.forEach(link => {
          link.classList.remove('active');
          if (link.getAttribute('href') === '#' + sectionId) {
            link.classList.add('active');
          }
        });
      }
    });
  }

  // 4. Interactive Before & After Comparison Slider
  const baWrapper = document.getElementById('ba-comparison-wrapper');
  const baAfterLayer = document.getElementById('ba-after-layer');
  const baHandle = document.getElementById('ba-slider-handle');
  const baAfterImg = document.getElementById('ba-after-img');
  const baBeforeImg = document.getElementById('ba-before-img');
  const galleryFilterBtns = document.querySelectorAll('.gallery-filter-btn');

  // Before & After Project Datasets
  const BA_PROJECTS = {
    interior: {
      before: "assets/before interior.jpg",
      after: "assets/after interior.jpg",
      beforeLabel: "Before: Worn & Faded Walls",
      afterLabel: "After: Master Smooth Satin Finish"
    },
    exterior: {
      before: "assets/after exerior.jpg",
      after: "assets/before exterior.jpg",
      beforeLabel: "After: Weatherproofed Chicago Exterior",
      afterLabel: "Before: Weathered Peeling Siding"
    },
    cabinets: {
      before: "assets/after kitchen.jpg",
      after: "assets/before kitchen.jpg",
      beforeLabel: "After: Spray-Applied Crisp White Finish",
      afterLabel: "Before: Dated Oak Cabinets"
    },
    decks: {
      before: "assets/after deck.jpg",
      after: "assets/before deck.jpg",
      beforeLabel: "After: Deep Penetrating Rich Stain",
      afterLabel: "Before: Grayed & Moldy Cedar"
    }
  };

  let isSliding = false;

  function updateSliderPosition(clientX) {
    if (!baWrapper || !baAfterLayer || !baHandle) return;
    const rect = baWrapper.getBoundingClientRect();
    let posX = clientX - rect.left;

    // Constrain within bounds
    if (posX < 0) posX = 0;
    if (posX > rect.width) posX = rect.width;

    const percentage = (posX / rect.width) * 100;
    baAfterLayer.style.width = percentage + '%';
    baHandle.style.left = percentage + '%';
  }

  if (baWrapper && baHandle) {
    // Mouse events
    baWrapper.addEventListener('mousedown', (e) => {
      isSliding = true;
      updateSliderPosition(e.clientX);
    });

    window.addEventListener('mouseup', () => {
      isSliding = false;
    });

    window.addEventListener('mousemove', (e) => {
      if (!isSliding) return;
      updateSliderPosition(e.clientX);
    });

    // Touch events
    baWrapper.addEventListener('touchstart', (e) => {
      if (e.touches.length === 1) {
        isSliding = true;
        updateSliderPosition(e.touches[0].clientX);
      }
    }, { passive: true });

    window.addEventListener('touchend', () => {
      isSliding = false;
    });

    window.addEventListener('touchmove', (e) => {
      if (!isSliding || e.touches.length !== 1) return;
      updateSliderPosition(e.touches[0].clientX);
    }, { passive: true });
  }

  // Gallery category tabs
  galleryFilterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const category = btn.getAttribute('data-filter');
      galleryFilterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const project = BA_PROJECTS[category] || BA_PROJECTS.interior;
      if (baBeforeImg && baAfterImg) {
        baBeforeImg.src = project.before;
        baAfterImg.src = project.after;

        const beforeLabelEl = document.getElementById('ba-before-label');
        const afterLabelEl = document.getElementById('ba-after-label');
        if (beforeLabelEl) beforeLabelEl.textContent = project.beforeLabel;
        if (afterLabelEl) afterLabelEl.textContent = project.afterLabel;
      }
    });
  });

  // 5. Service Cards "Request Quote" Integration
  const serviceQuoteBtns = document.querySelectorAll('.service-quote-trigger');
  const quoteServiceSelect = document.getElementById('quote-service-select');

  serviceQuoteBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const serviceName = btn.getAttribute('data-service-name');
      
      if (quoteServiceSelect && serviceName) {
        quoteServiceSelect.value = serviceName;
      }

      const quoteFormSection = document.getElementById('quote-form-section');
      if (quoteFormSection) {
        quoteFormSection.scrollIntoView({ behavior: 'smooth' });
        // Flash input focus
        setTimeout(() => {
          const nameInput = document.getElementById('quote-name');
          if (nameInput) nameInput.focus();
        }, 600);
      }
    });
  });

  // 6. Zip Code Checker
  const zipBtn = document.getElementById('check-zip-btn');
  const zipInput = document.getElementById('service-zip-input');
  const zipResultMsg = document.getElementById('zip-result-message');

  const SERVICED_ZIPS = [
    // Main Area: Oak Park, IL
    '60301', '60302', '60303', '60304',
    // Neighbor Areas: Berwyn & Stickney
    '60402',
    // Neighbor Area: Riverside
    '60546',
    // Neighbor Area: Hometown
    '60456',
    // Chicago proper
    '60601','60602','60603','60604','60605','60606','60607','60608','60609','60610',
    '60611','60612','60613','60614','60615','60616','60617','60618','60619','60620',
    '60621','60622','60623','60624','60625','60626','60628','60629','60630','60631',
    '60632','60634','60636','60637','60638','60639','60640','60641','60642','60643',
    '60644','60645','60646','60647','60649','60651','60652','60653','60654','60655',
    '60656','60657','60659','60660','60661',
    // Key suburbs
    '60804', // Cicero
    '60201', '60202', // Evanston
    '60130', // Forest Park
    '60540', '60563', '60564', // Naperville
    '60707'  // Elmwood Park
  ];

  if (zipBtn && zipInput && zipResultMsg) {
    zipBtn.addEventListener('click', () => {
      const val = zipInput.value.trim();
      if (!val || val.length < 5) {
        zipResultMsg.className = 'zip-result-message error';
        zipResultMsg.textContent = 'Please enter a valid 5-digit ZIP code.';
        return;
      }

      // Check match or general 606xx / Cook County radius
      const isServiced = SERVICED_ZIPS.includes(val) || val.startsWith('606') || val.startsWith('608') || val.startsWith('603') || val.startsWith('604') || val.startsWith('605');

      if (isServiced) {
        zipResultMsg.className = 'zip-result-message success';
        zipResultMsg.innerHTML = `✔ <strong>Great news!</strong> Bob's Decorating Service proudly services ZIP <strong>${val}</strong> in our Oak Park, Chicago, Berwyn, Stickney, Riverside & Hometown area! Our mobile estimating crew is ready to assist you.`;
      } else {
        zipResultMsg.className = 'zip-result-message success';
        zipResultMsg.innerHTML = `✔ We service Oak Park, Chicago, Berwyn, Stickney, Riverside, Hometown and surrounding Chicagoland communities (ZIP ${val}). Contact us directly at <strong>(773) 619-2417</strong> to confirm scheduling!`;
      }
    });

    zipInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        zipBtn.click();
      }
    });
  }

  // 7. FAQ Accordion
  const faqItems = document.querySelectorAll('.faq-item');

  faqItems.forEach(item => {
    const questionBtn = item.querySelector('.faq-question-btn');
    const answerContent = item.querySelector('.faq-answer-content');

    if (questionBtn && answerContent) {
      questionBtn.addEventListener('click', () => {
        const isOpen = item.classList.contains('active');

        // Close other items for neat single accordion view
        faqItems.forEach(otherItem => {
          if (otherItem !== item) {
            otherItem.classList.remove('active');
            const otherAnswer = otherItem.querySelector('.faq-answer-content');
            if (otherAnswer) otherAnswer.style.maxHeight = null;
          }
        });

        // Toggle clicked item
        if (isOpen) {
          item.classList.remove('active');
          answerContent.style.maxHeight = null;
        } else {
          item.classList.add('active');
          answerContent.style.maxHeight = answerContent.scrollHeight + 'px';
        }
      });
    }
  });

  // Open first FAQ item by default
  if (faqItems.length > 0) {
    const firstItem = faqItems[0];
    firstItem.classList.add('active');
    const firstAnswer = firstItem.querySelector('.faq-answer-content');
    if (firstAnswer) {
      firstAnswer.style.maxHeight = firstAnswer.scrollHeight + 'px';
    }
  }

  // 8. Photo Upload Simulator
  const fileDropzone = document.getElementById('photo-dropzone');
  const fileInput = document.getElementById('photo-file-input');
  const previewList = document.getElementById('file-preview-list');

  if (fileDropzone && fileInput) {
    fileDropzone.addEventListener('click', () => fileInput.click());

    fileInput.addEventListener('change', (e) => {
      const files = e.target.files;
      if (!files || !previewList) return;

      Array.from(files).forEach(file => {
        const tag = document.createElement('div');
        tag.className = 'preview-tag';
        tag.innerHTML = `
          <span>📷 ${file.name}</span>
          <button type="button" style="color:#ef4444; margin-left:4px;">✕</button>
        `;
        tag.querySelector('button').addEventListener('click', (ev) => {
          ev.stopPropagation();
          tag.remove();
        });
        previewList.appendChild(tag);
      });
    });
  }

  // 9. Quote Form Submission & Success Modal
  const quoteForm = document.getElementById('painting-quote-form');
  const successModal = document.getElementById('quote-success-modal');
  const closeModalBtn = document.getElementById('close-success-modal-btn');

  if (quoteForm) {
    quoteForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const nameVal = document.getElementById('quote-name').value.trim();
      const phoneVal = document.getElementById('quote-phone').value.trim();

      if (!nameVal || !phoneVal) {
        alert('Please provide your name and contact phone number so we can prepare your free estimate.');
        return;
      }

      // Simulate form submission
      const submitBtn = quoteForm.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerHTML;
      submitBtn.disabled = true;
      submitBtn.innerHTML = `<span>Submitting Request...</span>`;

      setTimeout(() => {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
        quoteForm.reset();
        if (previewList) previewList.innerHTML = '';

        if (successModal) {
          successModal.classList.add('show');
        }
      }, 700);
    });
  }

  if (closeModalBtn && successModal) {
    closeModalBtn.addEventListener('click', () => {
      successModal.classList.remove('show');
    });

    successModal.addEventListener('click', (e) => {
      if (e.target === successModal) {
        successModal.classList.remove('show');
      }
    });
  }

})();
