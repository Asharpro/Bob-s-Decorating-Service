/**
 * Bob's Decorating Service, Corp. - Three.js 3D Paint Studio & Swatch Visualizer
 * Real-time 3D Paint Can, Roller, Swatch Wall & Pigment Particles
 * Tailored with the brand's navy, orange, crimson and signature moss green palette
 */

(function () {
  'use strict';

  // Preset Designer Palettes matching the architectural design sample
  const PALETTES = {
    moss: {
      hex: '#556b4e',
      color: 0x556b4e,
      name: "Chicago Moss Olive (Signature Design Tone)",
      desc: "Rich, calming architectural interior & accent tone"
    },
    navy: {
      hex: '#0a2540',
      color: 0x0a2540,
      name: "Heritage Navy (Logo Accent)",
      desc: "Timeless Chicago exterior siding & entry door shade"
    },
    terracotta: {
      hex: '#c15c3d',
      color: 0xc15c3d,
      name: "Warm Terracotta (SW-6320)",
      desc: "Warm earth tone for dining, kitchens & accent walls"
    },
    cream: {
      hex: '#faf5eb',
      color: 0xfaf5eb,
      name: "Heritage Warm White (BM-OC-17)",
      desc: "Bright, airy whole-home Chicago classic"
    },
    slate: {
      hex: '#334155',
      color: 0x334155,
      name: "Architectural Slate (SW-7069)",
      desc: "Modern front doors, trim & commercial spaces"
    }
  };

  let activePaletteKey = 'moss';
  let scene, camera, renderer;
  let paintCanGroup, paintRollerGroup, swatchWallMesh, fluidMesh, rollerSleeveMesh;
  let particleGroup;
  let pointLightColor;
  let targetColor = new THREE.Color(PALETTES.moss.color);
  let currentColor = new THREE.Color(PALETTES.moss.color);

  // Mouse interaction state
  let mouseX = 0;
  let mouseY = 0;
  let targetRotationX = 0.15;
  let targetRotationY = -0.3;
  let isDragging = false;
  let prevMouseX = 0;
  let prevMouseY = 0;

  function initThree() {
    const container = document.getElementById('three-hero-canvas');
    if (!container || typeof THREE === 'undefined') {
      return;
    }

    const width = container.clientWidth || 450;
    const height = container.clientHeight || 340;

    // 1. Scene
    scene = new THREE.Scene();
    scene.background = null;

    // 2. Camera
    camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 1.2, 5.2);
    camera.lookAt(0, 0.2, 0);

    // 3. Renderer
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: true,
        alpha: true,
        powerPreference: "high-performance"
      });
    } catch (e) {
      console.warn("WebGL not supported:", e);
      return;
    }

    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(renderer.domElement);

    // 4. Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.85);
    scene.add(ambientLight);

    const mainDirLight = new THREE.DirectionalLight(0xfff7ed, 1.2);
    mainDirLight.position.set(4, 7, 5);
    mainDirLight.castShadow = true;
    scene.add(mainDirLight);

    const fillLight = new THREE.DirectionalLight(0xe0f2fe, 0.5);
    fillLight.position.set(-5, 3, 2);
    scene.add(fillLight);

    // Dynamic tint light reflecting the paint color
    pointLightColor = new THREE.PointLight(PALETTES.moss.color, 1.3, 6);
    pointLightColor.position.set(0.5, 1.5, 1.5);
    scene.add(pointLightColor);

    // 5. Build 3D Models
    createPaintStudio();
    createPigmentParticles();

    // 6. Event Listeners
    setupInteractions(container);
    setupSwatchButtons();

    // 7. Start Render Loop
    animate();
  }

  // Create textured label for paint can with official branding
  function createCanLabelTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 512;
    const ctx = canvas.getContext('2d');

    // Label background
    const gradient = ctx.createLinearGradient(0, 0, 1024, 0);
    gradient.addColorStop(0, '#0a2540');
    gradient.addColorStop(0.3, '#14355a');
    gradient.addColorStop(0.7, '#14355a');
    gradient.addColorStop(1, '#0a2540');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 1024, 512);

    // Top and Bottom Gold borders
    ctx.strokeStyle = '#f39200';
    ctx.lineWidth = 14;
    ctx.strokeRect(30, 30, 964, 452);

    // Star row
    ctx.fillStyle = '#f39200';
    ctx.font = 'bold 36px "Segoe UI", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('★ ★ ★ ★ ★  MASTER CRAFTSMANSHIP  ★ ★ ★ ★ ★', 512, 90);

    // Brand Name BOB'S
    ctx.fillStyle = '#ffffff';
    ctx.font = '900 78px "Plus Jakarta Sans", sans-serif';
    ctx.fillText("BOB'S", 512, 195);

    // DECORATING SERVICE, CORP. in crimson red
    ctx.fillStyle = '#e52424';
    ctx.font = 'bold 34px "Plus Jakarta Sans", sans-serif';
    ctx.letterSpacing = '6px';
    ctx.fillText('DECORATING SERVICE, CORP.', 512, 255);

    // Subtext
    ctx.fillStyle = '#cbd5e1';
    ctx.font = '500 28px "Segoe UI", sans-serif';
    ctx.fillText('51+ YEARS VETERAN-OWNED • CHICAGO, IL', 512, 320);

    // Orange accent bar
    ctx.fillStyle = '#f39200';
    ctx.fillRect(200, 350, 624, 8);

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 26px "Segoe UI", sans-serif';
    ctx.fillText('ARCHITECTURAL INTERIOR & EXTERIOR COATINGS', 512, 410);

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    return texture;
  }

  function createPaintStudio() {
    const studioGroup = new THREE.Group();

    // A. Swatch Background Wall
    const wallGeo = new THREE.PlaneGeometry(5, 3.2, 32, 32);
    const wallMat = new THREE.MeshStandardMaterial({
      color: PALETTES.moss.color,
      roughness: 0.35,
      metalness: 0.1,
      side: THREE.DoubleSide
    });
    swatchWallMesh = new THREE.Mesh(wallGeo, wallMat);
    swatchWallMesh.position.set(0, 0.4, -1.2);
    swatchWallMesh.receiveShadow = true;
    studioGroup.add(swatchWallMesh);

    // Wall frame/trim accent
    const frameGeo = new THREE.BoxGeometry(5.2, 0.08, 0.1);
    const frameMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.2 });
    const topTrim = new THREE.Mesh(frameGeo, frameMat);
    topTrim.position.set(0, 2.0, -1.15);
    studioGroup.add(topTrim);

    const baseTrim = new THREE.Mesh(frameGeo, frameMat);
    baseTrim.position.set(0, -1.2, -1.15);
    studioGroup.add(baseTrim);

    // B. Paint Can
    paintCanGroup = new THREE.Group();

    // Can body
    const canGeo = new THREE.CylinderGeometry(0.85, 0.85, 1.8, 48);
    const labelTexture = createCanLabelTexture();
    const canMat = new THREE.MeshStandardMaterial({
      map: labelTexture,
      roughness: 0.4,
      metalness: 0.35
    });
    const canBody = new THREE.Mesh(canGeo, canMat);
    canBody.castShadow = true;
    canBody.receiveShadow = true;
    paintCanGroup.add(canBody);

    // Metallic Rims (top and bottom)
    const rimMat = new THREE.MeshStandardMaterial({
      color: 0xcccccc,
      metalness: 0.85,
      roughness: 0.2
    });
    const topRimGeo = new THREE.TorusGeometry(0.86, 0.04, 16, 48);
    topRimGeo.rotateX(Math.PI / 2);
    const topRim = new THREE.Mesh(topRimGeo, rimMat);
    topRim.position.y = 0.9;
    paintCanGroup.add(topRim);

    const bottomRimGeo = new THREE.TorusGeometry(0.86, 0.03, 16, 48);
    bottomRimGeo.rotateX(Math.PI / 2);
    const bottomRim = new THREE.Mesh(bottomRimGeo, rimMat);
    bottomRim.position.y = -0.9;
    paintCanGroup.add(bottomRim);

    // Wet Paint Fluid Surface inside Can
    const fluidGeo = new THREE.CircleGeometry(0.8, 36);
    fluidGeo.rotateX(-Math.PI / 2);
    const fluidMat = new THREE.MeshStandardMaterial({
      color: PALETTES.moss.color,
      roughness: 0.15,
      metalness: 0.15
    });
    fluidMesh = new THREE.Mesh(fluidGeo, fluidMat);
    fluidMesh.position.y = 0.84;
    paintCanGroup.add(fluidMesh);

    // Wire Handle
    const handleGeo = new THREE.TorusGeometry(0.95, 0.025, 12, 36, Math.PI);
    const handleMesh = new THREE.Mesh(handleGeo, rimMat);
    handleMesh.position.set(0, 0.75, 0);
    handleMesh.rotation.z = Math.PI;
    handleMesh.rotation.x = 0.35;
    paintCanGroup.add(handleMesh);

    // Position the Paint Can
    paintCanGroup.position.set(-0.95, -0.2, 0.2);
    paintCanGroup.rotation.y = 0.4;
    studioGroup.add(paintCanGroup);

    // C. Professional Paint Roller
    paintRollerGroup = new THREE.Group();

    // Roller Sleeve
    const sleeveGeo = new THREE.CylinderGeometry(0.24, 0.24, 1.4, 32);
    sleeveGeo.rotateZ(Math.PI / 2);
    const sleeveMat = new THREE.MeshStandardMaterial({
      color: PALETTES.moss.color,
      roughness: 0.6,
      metalness: 0.05
    });
    rollerSleeveMesh = new THREE.Mesh(sleeveGeo, sleeveMat);
    rollerSleeveMesh.castShadow = true;
    paintRollerGroup.add(rollerSleeveMesh);

    // Chrome End Caps
    const capGeo = new THREE.CylinderGeometry(0.12, 0.12, 1.46, 24);
    capGeo.rotateZ(Math.PI / 2);
    const capMesh = new THREE.Mesh(capGeo, rimMat);
    paintRollerGroup.add(capMesh);

    // Wire Arm
    const wireMat = new THREE.MeshStandardMaterial({ color: 0xbbbbbb, metalness: 0.9, roughness: 0.15 });
    const arm1Geo = new THREE.CylinderGeometry(0.035, 0.035, 0.7, 16);
    const arm1 = new THREE.Mesh(arm1Geo, wireMat);
    arm1.position.set(0.75, -0.35, 0);
    paintRollerGroup.add(arm1);

    const arm2Geo = new THREE.CylinderGeometry(0.035, 0.035, 0.8, 16);
    arm2Geo.rotateZ(Math.PI / 2);
    const arm2 = new THREE.Mesh(arm2Geo, wireMat);
    arm2.position.set(0.35, -0.7, 0);
    paintRollerGroup.add(arm2);

    // Handle Grip
    const handleGripGeo = new THREE.CylinderGeometry(0.09, 0.11, 1.1, 24);
    const gripMat = new THREE.MeshStandardMaterial({
      color: 0x0a2540,
      roughness: 0.8
    });
    const handleGrip = new THREE.Mesh(handleGripGeo, gripMat);
    handleGrip.position.set(0, -1.25, 0);
    paintRollerGroup.add(handleGrip);

    // Accent Ring (Orange from logo)
    const gripRingGeo = new THREE.TorusGeometry(0.11, 0.02, 16, 24);
    gripRingGeo.rotateX(Math.PI / 2);
    const gripRingMat = new THREE.MeshStandardMaterial({ color: 0xf39200, metalness: 0.8, roughness: 0.3 });
    const gripRing = new THREE.Mesh(gripRingGeo, gripRingMat);
    gripRing.position.set(0, -0.75, 0);
    paintRollerGroup.add(gripRing);

    // Position the Paint Roller
    paintRollerGroup.position.set(1.1, 0.4, 0.4);
    paintRollerGroup.rotation.z = -0.35;
    paintRollerGroup.rotation.y = -0.3;
    paintRollerGroup.rotation.x = 0.2;
    studioGroup.add(paintRollerGroup);

    scene.add(studioGroup);
  }

  function createPigmentParticles() {
    particleGroup = new THREE.Group();
    const particleCount = 28;
    const sphereGeo = new THREE.SphereGeometry(0.06, 12, 12);

    for (let i = 0; i < particleCount; i++) {
      const mat = new THREE.MeshStandardMaterial({
        color: PALETTES.moss.color,
        roughness: 0.2,
        metalness: 0.3
      });
      const particle = new THREE.Mesh(sphereGeo, mat);
      
      particle.position.set(
        (Math.random() - 0.5) * 4.5,
        (Math.random() - 0.5) * 2.8,
        (Math.random() - 0.5) * 2.0 + 0.5
      );
      
      const scale = 0.4 + Math.random() * 0.9;
      particle.scale.set(scale, scale, scale);

      particle.userData = {
        speedY: (Math.random() - 0.5) * 0.008,
        speedX: (Math.random() - 0.5) * 0.005,
        originalY: particle.position.y
      };

      particleGroup.add(particle);
    }

    scene.add(particleGroup);
  }

  function setupInteractions(container) {
    container.addEventListener('mousedown', (e) => {
      isDragging = true;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    });

    window.addEventListener('mouseup', () => {
      isDragging = false;
    });

    container.addEventListener('mousemove', (e) => {
      const rect = container.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -(((e.clientY - rect.top) / rect.height) * 2 - 1);

      if (isDragging) {
        const deltaX = e.clientX - prevMouseX;
        const deltaY = e.clientY - prevMouseY;
        targetRotationY += deltaX * 0.008;
        targetRotationX += deltaY * 0.008;
        prevMouseX = e.clientX;
        prevMouseY = e.clientY;
      } else {
        mouseX = x * 0.4;
        mouseY = y * 0.3;
      }
    });

    // Touch support
    container.addEventListener('touchstart', (e) => {
      if (e.touches.length === 1) {
        isDragging = true;
        prevMouseX = e.touches[0].clientX;
        prevMouseY = e.touches[0].clientY;
      }
    }, { passive: true });

    window.addEventListener('touchend', () => {
      isDragging = false;
    });

    container.addEventListener('touchmove', (e) => {
      if (isDragging && e.touches.length === 1) {
        const deltaX = e.touches[0].clientX - prevMouseX;
        const deltaY = e.touches[0].clientY - prevMouseY;
        targetRotationY += deltaX * 0.008;
        targetRotationX += deltaY * 0.008;
        prevMouseX = e.touches[0].clientX;
        prevMouseY = e.touches[0].clientY;
      }
    }, { passive: true });

    window.addEventListener('resize', onWindowResize);
  }

  function onWindowResize() {
    const container = document.getElementById('three-hero-canvas');
    if (!container || !renderer || !camera) return;

    const width = container.clientWidth;
    const height = container.clientHeight;

    camera.aspect = width / height;
    camera.updateProjectionMatrix();
    renderer.setSize(width, height);
  }

  function setupSwatchButtons() {
    const swatchButtons = document.querySelectorAll('.color-swatch-btn');
    const activeLabelEl = document.getElementById('swatch-active-color-name');

    swatchButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        const colorKey = btn.getAttribute('data-color');
        if (!PALETTES[colorKey]) return;

        swatchButtons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        activePaletteKey = colorKey;
        const selected = PALETTES[colorKey];
        targetColor.set(selected.color);

        if (activeLabelEl) {
          activeLabelEl.textContent = selected.name;
        }
      });
    });
  }

  let clock = new THREE.Clock();

  function animate() {
    requestAnimationFrame(animate);

    const delta = clock.getDelta();
    const elapsedTime = clock.getElapsedTime();

    // Smooth color interpolation
    currentColor.lerp(targetColor, 0.06);

    if (swatchWallMesh && swatchWallMesh.material) {
      swatchWallMesh.material.color.copy(currentColor);
    }
    if (fluidMesh && fluidMesh.material) {
      fluidMesh.material.color.copy(currentColor);
    }
    if (rollerSleeveMesh && rollerSleeveMesh.material) {
      rollerSleeveMesh.material.color.copy(currentColor);
    }
    if (pointLightColor) {
      pointLightColor.color.copy(currentColor);
    }

    if (particleGroup) {
      particleGroup.children.forEach(p => {
        if (p.material) {
          p.material.color.copy(currentColor);
        }
        p.position.y = p.userData.originalY + Math.sin(elapsedTime * 1.5 + p.position.x) * 0.15;
        p.rotation.y += 0.01;
      });
    }

    if (paintCanGroup) {
      paintCanGroup.position.y = -0.2 + Math.sin(elapsedTime * 1.2) * 0.06;
      paintCanGroup.rotation.y += 0.003;
    }

    if (paintRollerGroup) {
      paintRollerGroup.position.y = 0.4 + Math.cos(elapsedTime * 1.5) * 0.08;
      paintRollerGroup.rotation.x = 0.2 + Math.sin(elapsedTime * 1.0) * 0.04;
    }

    if (!isDragging) {
      targetRotationY = -0.3 + mouseX * 0.35 + Math.sin(elapsedTime * 0.4) * 0.05;
      targetRotationX = 0.15 - mouseY * 0.25;
    }

    scene.rotation.y += (targetRotationY - scene.rotation.y) * 0.05;
    scene.rotation.x += (targetRotationX - scene.rotation.x) * 0.05;

    renderer.render(scene, camera);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initThree);
  } else {
    initThree();
  }

})();
